# Pseudopotentials
- Use PSLibrary or SSSP. Place UPFs under ./pp. Example: Si.pbe-n-rrkjus_psl.1.0.0.UPF.
- See QE PP portal for formats and sources.
